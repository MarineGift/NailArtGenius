module.exports = {
  plugins: {
    tailwindcss: {
      config: './config/tailwind.config.js'
    },
    autoprefixer: {},
  },
}