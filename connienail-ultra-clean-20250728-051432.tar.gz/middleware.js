// Import middleware from config folder
export { middleware, config } from './config/middleware.js';